import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

day = pd.read_csv("cleaned_df_day.csv")
hour = pd.read_csv("cleaned_df_hour.csv") 

tab1,tab2,tab3 = st.tabs(["Grafik", "Pie Chart: Registered",
                               "Pie Chart: Casual"])


# Tab pertama: Menampilkan grafik Perbandingan Jumlah Pengguna di Hari Libur dan Hari Kerja
with tab1:

    fig, _ = plt.subplots(figsize=(9,7))
    sns.barplot(data=day, x="workingday", y="registered", errorbar=None, color='red')
    sns.barplot(data=day, x="workingday", y="casual", errorbar=None, color='blue')
    plt.title('Perbandingan Jumlah Pengguna di Hari Libur dan Hari Kerja (0:Libur; 1:Kerja)')
    plt.ylabel('Jumlah pengguna')
    plt.xlabel('Hari kerja')
    plt.legend(['Regsitered', 'Casual'])
    plt.grid(True)
    plt.show()
    
    # Menampilkan grafik di tab 1
    st.pyplot(fig)

#Tabel pivot perbadingan pengguna tiap musim
season_df = day.groupby(by='season').agg({
    'casual':'sum',
    'registered':'sum',
    'cnt':'sum'
}).sort_values(by='cnt', ascending=False)

# Tab kedua: Menampilkan grafik pengguna registered
with tab2:
    season = ('fall','summer','winter','spring')
    colors = ('r', 'm', '#93C572', 'c')
    explode = (0.05, 0, 0, 0)
    
    fig, ax = plt.subplots(figsize=(7, 7))

    patches, texts, pcts = ax.pie(
        season_df['registered'], labels=season, autopct='%.1f%%', colors=colors,
        wedgeprops={'linewidth': 1, 'edgecolor': 'white'},
        textprops={'size': 'x-large'}, explode=explode)

    plt.setp(pcts, color='black', fontweight='bold')
    ax.set_title('Jumlah Pengguna Registered Setiap Musim', fontsize=18)
    plt.tight_layout()
    
    # Menampilkan grafik di tab 2
    st.pyplot(fig)


# Tab ketiga: Menampilkan grafik pengguna casual
with tab3:
    season = ('fall','summer','winter','spring')
    colors = ('r', 'm', '#93C572', 'c')
    explode = (0.05, 0, 0, 0)
    
    fig, ax = plt.subplots(figsize=(7, 7))

    patches, texts, pcts = ax.pie(
        season_df['casual'], labels=season, autopct='%.1f%%', colors=colors,
        wedgeprops={'linewidth': 1, 'edgecolor': 'white'},
        textprops={'size': 'x-large'}, explode=explode)

    plt.setp(pcts, color='black', fontweight='bold')
    ax.set_title('Jumlah Pengguna Casual Setiap Musim', fontsize=18)
    plt.tight_layout()
    
    # Menampilkan grafik di tab 3
    st.pyplot(fig)