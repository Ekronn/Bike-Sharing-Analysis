**Pada Shell/Terminal:**

`cd '.\Dicoding\Tugas Akhir\dashboard'`

`pip install -r requirements.txt `


**Jalankan Dashboard Streamlit:**

`streamlit run dashboard.py `
